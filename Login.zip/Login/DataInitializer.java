package Login;

import Login.Modelo_basico.Usuario;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner initDatabase(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            String emailPadrao = "adm@email.com";

            // Cria o utilizador apenas se ele ainda não existir na base de dados
            if (usuarioRepository.findByEmail(emailPadrao).isEmpty()) {
                Usuario admin = new Usuario(
                        "Administrador",
                        emailPadrao,
                        passwordEncoder.encode("12345678") // Senha pura que será encriptada
                );

                usuarioRepository.save(admin);
                System.out.println(">>> Utilizador padrão criado com sucesso!");
                System.out.println(">>> E-mail: adm@email.com | Senha: 12345678");
            }
        };
    }
}